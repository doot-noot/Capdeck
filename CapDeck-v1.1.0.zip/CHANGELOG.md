# Changelog

All notable changes to CapDeck. Format based on [Keep a Changelog](https://keepachangelog.com/),
versions follow [Semantic Versioning](https://semver.org/).

## Provenance

CapDeck is developed by **doot-noot** (project owner: features, testing on hardware, releases) with
**Claude (Anthropic), an AI coding assistant**, which wrote the firmware code to the owner's specifications.
Each release lists who did what. Release binaries are built from the `source/` folder of the same tag, and
their SHA-256 checksums are in `SHA256SUMS.txt`.

---

## [1.1.0] - 2026-11-03

### Added
- **Mesh app**: passive Meshtastic listener (receive-only). Decodes packets on the public default channel
  (AES-128-CTR with the published default key): node names, positions, public text messages. Node list sorted by
  last heard, node details (distance/bearing from your GPS fix, RSSI/SNR, hops), public message log
  (`/capdeck/mesh/messages.txt`), and nodes saved across reboots (`/capdeck/mesh/nodes.csv`). Modem preset
  selectable: LongFast, MediumFast, MediumSlow, LongSlow, LongMod, ShortFast, ShortSlow, ShortTurbo, each on its
  US default slot.
- **Mesh map**: web-mercator map centred on your GPS fix (or last known position) with range rings, scale bar,
  north arrow, node labels and freshness colouring. Zoom with `,` `/`, jump between nodes with `;` `.`.
  Optional offline tiles from `/capdeck/map/z/x/y.png|jpg`.
- **LoRa scanner**: 902–928 MHz RSSI spectrum (250 kHz bins) with peak hold and a waterfall, plus a
  channel-activity-detection "hunter" across Meshtastic presets, LoRaWAN US915 sub-band 2 (SF7–10) and CapDeck chat.
- **Local AI app**: chat with any OpenAI-compatible server (llama.cpp `llama-server`, Ollama, LM Studio). Hides
  `<think>` blocks, has a connection test that lists the server's models, and can set the server address and model
  on the device.
- **Portal app**: WPA2 hotspot (`CapDeck-XXXX`, random password, QR code to join) with a captive-portal web app:
  local-AI chat, `config.json` editor with JSON validation and live reload, SD file manager (browse, upload,
  download, delete, new folder), Meshtastic node table with map links, device status, reboot. Also served on the
  home-network IP behind HTTP basic auth.
- **Themes**: Default, Cyber (neon synthwave grid and split-colour titles), Matrix (glyph rain), Amber (CRT
  scanlines). All built in, no SD files needed. Config → Theme.
- New icons: Local AI, Mesh, Portal, Scanner, Map.
- Status bar indicators for portal running and Meshtastic listening.
- `CLAUDE.md` (build guide for AI-assisted maintenance), `LICENSE`, `THIRD_PARTY_NOTICES.md`, `SHA256SUMS.txt`.

### Changed
- Main menu now has 10 apps. `0` jumps to the 10th.
- Accent colour defaults to the theme's own accent.
- Radio is shared by mode: CapDeck chat, Meshtastic listening, or scanning. Switching asks first.
- `config.json` gains a `local_ai` section (added automatically by the portal or on-device editor).

### Fixed
- Local AI replies that use chunked transfer encoding are read correctly.

### Credits
- doot-noot: feature requests (scanner, Meshtastic map, themes, phone portal, local AI), hardware details,
  testing of v1.0.0 on device.
- Claude (Anthropic): implementation, Meshtastic packet/crypto format verified against the
  meshtastic/firmware and meshtastic/protobufs sources, build, rendered UI previews.

### Known limitations
- Not yet tested on hardware: Mesh, Scanner, Portal, Local AI, themes (compiled and UI-rendered only).
- Meshtastic is receive-only. Nodes that don't opt in to sharing position won't appear on the map.
- Push-to-talk Assist needs Home Assistant on plain `http://`.

## [1.0.0] - 2026-11-02

### Added
- Icon carousel UI with per-app vector icons and colours; status bar (clock, battery, Wi-Fi, GPS, LoRa mail).
- Home Assistant: trigger deck with live states and OK/FAILED notices; push-to-talk Assist over the websocket
  pipeline API with spoken replies (TTS as 16 kHz WAV); typed Assist chat; connection status.
- LoRa (Cap LoRa-1262 / SX1262): chat between CapDecks, packet monitor with signal meter, ping, radio settings saved
  to `config.json`, background receive with notifications.
- GPS: fix readout, satellite radar, waypoint CSV logging, clock sync from GPS.
- Infrared: Flipper `.ir` file sender (raw + NEC/NECext/Samsung32/SIRC/RC5/RC5X/RC6), sweep-all.
- RF 433: RCSwitch decoding, logic scope, saved codes, optional forward to an HA webhook, replay with a transmitter.
- Files: SD browser with viewer/hex dump, rename, delete, folders.
- Config: 7-segment clock, battery graph, Wi-Fi scan/connect, brightness/dim/accent, sound, system info,
  return to M5Launcher, sleep, reboot.

### Credits
- doot-noot: concept, feature list, hardware (Cardputer ADV, Cap LoRa-1262, RX470C), naming.
- Claude (Anthropic): implementation and packaging.
