// CapDeck - UI toolkit: input, status bar, lists, text entry, popups
#include "core.h"

M5Canvas canvas(&M5Cardputer.Display);

static const uint16_t ACCENTS[] = {0x07FF, 0xF81F, 0x07E0, 0xFD20, 0x3D7F, 0xF8A6};
uint16_t accent() { return ACCENTS[cfg.accentIdx % (sizeof(ACCENTS) / sizeof(ACCENTS[0]))]; }

// ------------------------------------------------------------------ input
static Key lastKey;
static bool keyHeld = false;
static uint32_t heldSince = 0, lastRepeat = 0;
static uint32_t lastActivity = 0;
static bool dimmed = false;

void wakeScreen() {
  lastActivity = millis();
  if (dimmed) {
    dimmed = false;
    applyBrightness();
  }
}

static Key decode(Keyboard_Class::KeysState &st) {
  Key k;
  k.fn = st.fn;
  k.enter = st.enter;
  k.tab = st.tab;
  k.space = st.space;
  k.del = st.backspace || st.del;
  if (!st.word.empty()) k.ch = st.word.back();
  if (st.fn) {
    k.up = st.up;
    k.down = st.down;
    k.left = st.left;
    k.right = st.right;
    k.esc = st.esc;
    k.ch = 0;
  } else {
    switch (k.ch) {
      case ';': k.up = true; break;
      case '.': k.down = true; break;
      case ',': k.left = true; break;
      case '/': k.right = true; break;
      case '`': k.esc = true; break;
    }
  }
  k.back = k.del || k.esc;
  k.any = k.enter || k.tab || k.del || k.esc || k.up || k.down || k.left || k.right || k.ch || k.space;
  return k;
}

Key readKey() {
  sysTick();
  Key k;
  auto &kb = M5Cardputer.Keyboard;
  uint32_t now = millis();
  if (kb.isChange()) {
    if (kb.isPressed()) {
      k = decode(kb.keysState());
      keyHeld = k.any;
      lastKey = k;
      heldSince = lastRepeat = now;
    } else {
      keyHeld = false;
    }
  } else if (keyHeld && kb.isPressed()) {
    bool repeatable = lastKey.up || lastKey.down || lastKey.left || lastKey.right || lastKey.del;
    if (repeatable && now - heldSince > 380 && now - lastRepeat > 70) {
      k = lastKey;
      k.repeat = true;
      lastRepeat = now;
    }
  }
  if (M5Cardputer.BtnA.wasPressed()) {
    k = Key();
    k.enter = k.any = true;
  }
  if (k.any) {
    bool wasDim = dimmed;
    wakeScreen();
    if (wasDim) return Key();  // first press only wakes the screen
  } else if (cfg.dimSecs && !dimmed && now - lastActivity > cfg.dimSecs * 1000UL) {
    dimmed = true;
    M5Cardputer.Display.setBrightness(max(8, cfg.brightness / 8));
  }
  return k;
}

bool talkKeyHeld() {
  auto &st = M5Cardputer.Keyboard.keysState();
  return st.space || st.enter || M5Cardputer.BtnA.isPressed();
}

void beep(int freq, int ms) {
  if (cfg.sound) M5Cardputer.Speaker.tone(freq, ms);
}

void pushFrame() { canvas.pushSprite(0, 0); }

String humanSize(uint64_t b) {
  char buf[16];
  if (b < 1024) snprintf(buf, sizeof buf, "%uB", (unsigned)b);
  else if (b < 1024 * 1024) snprintf(buf, sizeof buf, "%.1fK", b / 1024.0);
  else if (b < 1024ULL * 1024 * 1024) snprintf(buf, sizeof buf, "%.1fM", b / 1048576.0);
  else snprintf(buf, sizeof buf, "%.1fG", b / 1073741824.0);
  return buf;
}

// ------------------------------------------------------------------ status bar
void drawBattery(LovyanGFX &g, int x, int y, int level, uint16_t c) {
  g.drawRoundRect(x, y, 18, 9, 2, c);
  g.fillRect(x + 18, y + 2, 2, 5, c);
  int w = constrain(level, 0, 100) * 14 / 100;
  uint16_t fill = level > 50 ? col::OK : level > 20 ? col::WARN : col::BAD;
  if (w > 0) g.fillRect(x + 2, y + 2, w, 5, fill);
}

void drawWifiGlyph(LovyanGFX &g, int x, int y, int bars, uint16_t c) {
  for (int i = 0; i < 4; i++) {
    int h = 2 + i * 2;
    g.fillRect(x + i * 3, y + 9 - h, 2, h, i < bars ? c : col::FAINT);
  }
}

void drawStatusBar(const char *title, uint16_t color) {
  canvas.fillRect(0, 0, SCR_W, BAR_H, 0x0020);
  canvas.drawFastHLine(0, BAR_H - 1, SCR_W, col::FAINT);
  canvas.setFont(&fonts::Font0);
  canvas.setTextSize(1);
  canvas.setTextDatum(middle_left);
  canvas.setTextColor(col::TEXT);
  canvas.drawString(timeValid() ? timeStr() : "--:--", 4, 7);
  if (title && *title) {
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(color);
    canvas.drawString(title, SCR_W / 2, 7);
  }
  // right side icons, laid out right-to-left
  int x = SCR_W - 4;
  int lvl = M5Cardputer.Power.getBatteryLevel();
  x -= 20;
  drawBattery(canvas, x, 2, lvl, col::TEXT);
  canvas.setTextDatum(middle_right);
  canvas.setTextColor(col::DIM);
  char pct[6];
  snprintf(pct, sizeof pct, "%d%%", lvl);
  canvas.drawString(pct, x - 2, 7);
  x -= canvas.textWidth(pct) + 6;
  if (netState() == NetState::UP) {
    int rssi = WiFi.RSSI();
    int bars = rssi > -55 ? 4 : rssi > -67 ? 3 : rssi > -78 ? 2 : 1;
    x -= 12;
    drawWifiGlyph(canvas, x, 2, bars, col::OK);
    x -= 4;
  } else if (netState() == NetState::CONNECTING) {
    x -= 12;
    drawWifiGlyph(canvas, x, 2, (millis() / 300) % 5, col::WARN);
    x -= 4;
  }
  if (gpsFix()) {
    x -= 8;
    canvas.fillCircle(x + 3, 6, 3, col::GPS);
    canvas.fillTriangle(x, 7, x + 6, 7, x + 3, 12, col::GPS);
    canvas.fillCircle(x + 3, 6, 1, 0x0020);
    x -= 4;
  }
  if (loraUnread > 0) {
    x -= 12;
    canvas.drawRect(x, 3, 11, 8, col::LORA);
    canvas.drawLine(x, 3, x + 5, 7, col::LORA);
    canvas.drawLine(x + 10, 3, x + 5, 7, col::LORA);
    x -= 4;
  }
}

void drawHeader(const char *title, uint16_t color, uint8_t icon) {
  canvas.fillScreen(col::BG);
  drawStatusBar(nullptr, color);
  canvas.fillRect(0, BAR_H, SCR_W, 18, col::PANEL);
  canvas.fillRect(0, BAR_H + 17, SCR_W, 1, color);
  int tx = 6;
  if (icon != 255) {
    drawIcon(canvas, icon, 13, BAR_H + 9, 14, color, col::PANEL);
    tx = 24;
  }
  canvas.setFont(&fonts::FreeSansBold9pt7b);
  canvas.setTextDatum(middle_left);
  canvas.setTextColor(col::TEXT);
  canvas.drawString(title, tx, BAR_H + 9);
}

// ------------------------------------------------------------------ text wrap / popups
void wrapText(const String &text, int width, std::vector<String> &out) {
  int start = 0;
  int n = text.length();
  while (start <= n) {
    int nl = text.indexOf('\n', start);
    String para = text.substring(start, nl < 0 ? n : nl);
    // greedy wrap of one paragraph
    while (true) {
      if (canvas.textWidth(para) <= width) {
        out.push_back(para);
        break;
      }
      int cut = para.length();
      while (cut > 1 && canvas.textWidth(para.substring(0, cut)) > width) cut--;
      int sp = para.lastIndexOf(' ', cut);
      if (sp > 0) cut = sp;
      out.push_back(para.substring(0, cut));
      para = para.substring(cut);
      para.trim();
      if (!para.length()) break;
    }
    if (nl < 0) break;
    start = nl + 1;
  }
}

static void drawPanel(int x, int y, int w, int h, uint16_t color) {
  canvas.fillRoundRect(x + 2, y + 3, w, h, 6, 0x0000);
  canvas.fillRoundRect(x, y, w, h, 6, col::PANEL2);
  canvas.drawRoundRect(x, y, w, h, 6, color);
}

void toast(const String &msg, uint16_t color, uint32_t ms) {
  if (!color) color = accent();
  canvas.setFont(&fonts::Font2);
  std::vector<String> lines;
  wrapText(msg, 196, lines);
  if (lines.size() > 5) lines.resize(5);
  int h = lines.size() * 16 + 16;
  int y = (SCR_H - h) / 2 + 6;
  drawPanel(14, y, SCR_W - 28, h, color);
  canvas.setTextDatum(top_center);
  canvas.setTextColor(col::TEXT);
  for (size_t i = 0; i < lines.size(); i++) canvas.drawString(lines[i], SCR_W / 2, y + 8 + i * 16);
  pushFrame();
  uint32_t t = millis();
  while (millis() - t < ms) {
    Key k = readKey();
    if (k.any && millis() - t > 150) break;
    delay(10);
  }
}

bool confirmBox(const String &q, uint16_t color) {
  canvas.setFont(&fonts::Font2);
  std::vector<String> lines;
  wrapText(q, 196, lines);
  if (lines.size() > 4) lines.resize(4);
  int h = lines.size() * 16 + 34;
  int y = (SCR_H - h) / 2 + 6;
  drawPanel(14, y, SCR_W - 28, h, color);
  canvas.setTextDatum(top_center);
  canvas.setTextColor(col::TEXT);
  for (size_t i = 0; i < lines.size(); i++) canvas.drawString(lines[i], SCR_W / 2, y + 7 + i * 16);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(color);
  canvas.drawString("ENTER = yes    DEL = no", SCR_W / 2, y + h - 14);
  pushFrame();
  while (true) {
    Key k = readKey();
    if (k.enter || k.ch == 'y') return true;
    if (k.back || k.ch == 'n') return false;
    delay(10);
  }
}

// ------------------------------------------------------------------ list menu
int listMenu(const char *title, uint16_t color, std::vector<ListItem> &items, int &sel, uint8_t icon,
             std::function<void()> onIdle) {
  const int top = BAR_H + 19, rowH = 20;
  const int rows = (SCR_H - top) / rowH;
  int scroll = 0;
  bool dirty = true;
  uint32_t lastDraw = 0;
  if (sel >= (int)items.size()) sel = items.size() - 1;
  if (sel < 0) sel = 0;
  while (true) {
    Key k = readKey();
    int n = items.size();
    if (k.up && n) { sel = (sel - 1 + n) % n; dirty = true; beep(1800, 8); }
    if (k.down && n) { sel = (sel + 1) % n; dirty = true; beep(1800, 8); }
    if (k.left && n) { sel = max(0, sel - rows); dirty = true; }
    if (k.right && n) { sel = min(n - 1, sel + rows); dirty = true; }
    if (k.enter && n) { beep(2600, 20); return sel; }
    if (k.back) { beep(1200, 20); return -1; }
    if (k.ch >= '1' && k.ch <= '9' && (k.ch - '1') < n) { sel = k.ch - '1'; beep(2600, 20); return sel; }
    if (onIdle) onIdle();
    if (millis() - lastDraw > 1000) dirty = true;  // keep clock fresh
    if (!dirty) { delay(8); continue; }
    dirty = false;
    lastDraw = millis();
    if (sel < scroll) scroll = sel;
    if (sel >= scroll + rows) scroll = sel - rows + 1;
    drawHeader(title, color, icon);
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(middle_right);
    canvas.setTextColor(col::DIM);
    char pos[12];
    snprintf(pos, sizeof pos, "%d/%d", n ? sel + 1 : 0, n);
    canvas.drawString(pos, SCR_W - 6, BAR_H + 9);
    if (!n) {
      canvas.setFont(&fonts::Font2);
      canvas.setTextDatum(middle_center);
      canvas.drawString("(empty)", SCR_W / 2, top + 40);
    }
    for (int r = 0; r < rows && scroll + r < n; r++) {
      int i = scroll + r;
      int y = top + r * rowH;
      ListItem &it = items[i];
      uint16_t ic = it.color ? it.color : color;
      bool on = i == sel;
      if (on) {
        canvas.fillRoundRect(3, y + 1, SCR_W - 12, rowH - 2, 5, ic);
      }
      int tx = 9;
      if (it.icon != 255) {
        drawIcon(canvas, it.icon, 17, y + rowH / 2, 13, on ? col::BG : ic, on ? ic : col::BG);
        tx = 29;
      }
      canvas.setFont(&fonts::Font2);
      canvas.setTextDatum(middle_left);
      canvas.setTextColor(on ? col::BG : col::TEXT);
      String label = it.label;
      int maxW = SCR_W - tx - 14 - (it.right.length() ? canvas.textWidth(it.right) + 6 : 0);
      while (label.length() > 1 && canvas.textWidth(label) > maxW) label.remove(label.length() - 1);
      canvas.drawString(label, tx, y + rowH / 2 + 1);
      if (it.right.length()) {
        canvas.setTextDatum(middle_right);
        canvas.setTextColor(on ? col::BG : col::DIM);
        canvas.drawString(it.right, SCR_W - 14, y + rowH / 2 + 1);
      }
    }
    // scrollbar
    if (n > rows) {
      int trackH = SCR_H - top - 4;
      int barH = max(8, trackH * rows / n);
      int barY = top + 2 + (trackH - barH) * scroll / max(1, n - rows);
      canvas.fillRect(SCR_W - 5, top + 2, 2, trackH, col::FAINT);
      canvas.fillRect(SCR_W - 6, barY, 4, barH, color);
    }
    pushFrame();
  }
}

// ------------------------------------------------------------------ text input
bool textInput(const char *title, String &value, uint16_t color, bool secret, int maxLen) {
  String v = value;
  bool dirty = true;
  uint32_t blink = millis();
  bool caret = true;
  while (true) {
    Key k = readKey();
    if (k.any) {
      dirty = true;
      if (k.enter) { value = v; beep(2600, 20); return true; }
      if (k.esc) { beep(1200, 20); return false; }
      if (k.del) {
        if (v.length()) v.remove(v.length() - 1);
        else { beep(1200, 20); return false; }  // DEL on empty = cancel
      } else if (k.tab) {
        if ((int)v.length() < maxLen) v += ' ';
      } else if (k.ch && !k.fn && (int)v.length() < maxLen) {
        v += k.ch;
      }
    }
    if (millis() - blink > 450) { blink = millis(); caret = !caret; dirty = true; }
    if (!dirty) { delay(10); continue; }
    dirty = false;
    drawHeader(title, color);
    // input box
    canvas.fillRoundRect(6, 44, SCR_W - 12, 34, 6, col::PANEL);
    canvas.drawRoundRect(6, 44, SCR_W - 12, 34, 6, color);
    canvas.setFont(&fonts::FreeSans9pt7b);
    canvas.setTextDatum(middle_left);
    canvas.setTextColor(col::TEXT);
    String shown = v;
    if (secret && shown.length()) {
      String m;
      for (size_t i = 0; i + 1 < shown.length(); i++) m += '*';
      m += shown[shown.length() - 1];
      shown = m;
    }
    while (shown.length() && canvas.textWidth(shown) > SCR_W - 30) shown.remove(0, 1);
    canvas.drawString(shown, 14, 61);
    if (caret) canvas.fillRect(14 + canvas.textWidth(shown) + 1, 52, 2, 18, color);
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(top_left);
    canvas.setTextColor(col::DIM);
    canvas.drawString("ENTER save   DEL erase   ` cancel", 8, 88);
    char cnt[16];
    snprintf(cnt, sizeof cnt, "%d/%d", (int)v.length(), maxLen);
    canvas.setTextDatum(top_right);
    canvas.drawString(cnt, SCR_W - 8, 100);
    canvas.setTextDatum(top_left);
    canvas.drawString("Shift for capitals & symbols", 8, 100);
    pushFrame();
  }
}

// ------------------------------------------------------------------ text viewer
void textViewer(const char *title, const String &text, uint16_t color) {
  canvas.setFont(&fonts::Font0);
  std::vector<String> lines;
  wrapText(text, SCR_W - 16, lines);
  const int top = BAR_H + 21, lh = 10;
  const int rows = (SCR_H - top) / lh;
  int scroll = 0;
  bool dirty = true;
  while (true) {
    Key k = readKey();
    int maxScroll = max(0, (int)lines.size() - rows);
    if (k.up) { scroll = max(0, scroll - 1); dirty = true; }
    if (k.down) { scroll = min(maxScroll, scroll + 1); dirty = true; }
    if (k.left) { scroll = max(0, scroll - rows); dirty = true; }
    if (k.right || k.space) { scroll = min(maxScroll, scroll + rows); dirty = true; }
    if (k.back || k.enter) return;
    if (!dirty) { delay(10); continue; }
    dirty = false;
    drawHeader(title, color);
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(top_left);
    canvas.setTextColor(col::TEXT);
    for (int r = 0; r < rows && scroll + r < (int)lines.size(); r++)
      canvas.drawString(lines[scroll + r], 6, top + r * lh);
    if ((int)lines.size() > rows) {
      int trackH = SCR_H - top - 2;
      int barH = max(6, trackH * rows / (int)lines.size());
      int barY = top + (trackH - barH) * scroll / max(1, maxScroll);
      canvas.fillRect(SCR_W - 4, barY, 3, barH, color);
    }
    pushFrame();
  }
}
